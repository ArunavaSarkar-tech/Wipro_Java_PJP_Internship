package com.wipro.automobile.ship;

public class Compartment{
    public double height, width, depth;
}
