public class General extends Compartment{
    public String notice(){
        return "General Compartment";
    }
}
