public interface LibraryUser{
    public abstract void registerAccount();
    public abstract void requestBook();
}
