var today = new Date();
print(today);
