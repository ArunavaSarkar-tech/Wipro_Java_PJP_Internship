function changeBG(color) {
    document.body.style.backgroundColor = color;
}
