function uppercase() {
    var text = document.getElementById("text");
    text.value = text.value.toUpperCase();
}
