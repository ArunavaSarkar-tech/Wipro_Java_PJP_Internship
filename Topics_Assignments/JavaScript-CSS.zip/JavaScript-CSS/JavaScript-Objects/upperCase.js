let txt = prompt("Enter Text :");
document.write("Entered Text : " + txt + "<br>");
document.write("Upper Cased : " + txt.toUpperCase());
