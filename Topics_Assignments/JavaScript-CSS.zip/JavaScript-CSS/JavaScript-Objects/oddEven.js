let num = Number(prompt("Enter a number to check Odd/Even: "));

alert(num % 2 === 0 ? "Even" : "Odd");
