create table dept(
    dept_id number (7),
    dept_name varchar2 (20),
    primary key(dept_id)
);

describe dept;
