select last_name, salary, commission from employees
where commission is not null order by 2 desc, 3 desc;

