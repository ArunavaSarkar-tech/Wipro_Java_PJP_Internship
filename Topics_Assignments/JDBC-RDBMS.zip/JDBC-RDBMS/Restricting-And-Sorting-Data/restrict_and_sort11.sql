select emp_ID, last_name, salary, dept_ID from employees
where manager_ID = &man_ID order by &col;

