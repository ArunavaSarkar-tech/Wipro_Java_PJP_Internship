select last_name, job_ID, hire_date from employees
where last_name in ('Matos', 'Taylor') order by hire_date;

