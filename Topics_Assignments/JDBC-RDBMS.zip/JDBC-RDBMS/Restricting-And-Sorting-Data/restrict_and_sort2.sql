select last_name, dept_ID from employees
where emp_ID = '176';

