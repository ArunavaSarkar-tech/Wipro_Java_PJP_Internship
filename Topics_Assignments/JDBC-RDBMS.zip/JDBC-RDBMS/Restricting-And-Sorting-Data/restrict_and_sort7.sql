select last_name, hire_date from employees
where year(hire_date) = 1994;

