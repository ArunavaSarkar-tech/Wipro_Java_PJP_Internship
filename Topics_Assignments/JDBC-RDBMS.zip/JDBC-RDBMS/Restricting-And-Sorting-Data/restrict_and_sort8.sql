select last_name, job_ID from employees
where manager is null;

