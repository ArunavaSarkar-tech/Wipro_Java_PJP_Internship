select last_name, dept_ID from employees
where dept_ID in (20, 50) order by last_name;

