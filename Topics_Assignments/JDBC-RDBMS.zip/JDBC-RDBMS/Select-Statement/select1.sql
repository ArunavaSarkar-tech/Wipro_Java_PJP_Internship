describe departments;

