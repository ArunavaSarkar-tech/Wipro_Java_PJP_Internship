select distinct job_ID from employees;

