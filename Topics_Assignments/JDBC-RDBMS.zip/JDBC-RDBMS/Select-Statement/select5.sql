select last_name || ' ' || job_ID "Employee and Title" from employees;

