select emp_ID "Emp #", last_name "Employee", job_ID "Job", hire_date "Hire Date" from employees;

