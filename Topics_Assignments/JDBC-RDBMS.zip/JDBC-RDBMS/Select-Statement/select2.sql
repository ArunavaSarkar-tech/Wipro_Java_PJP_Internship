select emp_ID, last_name, job_ID, hire_date "STARTDATE" from employees;

