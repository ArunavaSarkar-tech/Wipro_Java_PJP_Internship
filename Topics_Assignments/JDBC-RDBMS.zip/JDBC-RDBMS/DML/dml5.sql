insert into my_employee (employee_id, first_name, last_name, department_id)
values(203, 'Susan', 'Mavris', 40);
select * from my_employee;
