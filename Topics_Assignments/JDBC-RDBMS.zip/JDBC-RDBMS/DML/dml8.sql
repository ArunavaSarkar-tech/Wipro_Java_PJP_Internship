update my_employee set last_name = 'Higgins'
where employee_id = 202;
