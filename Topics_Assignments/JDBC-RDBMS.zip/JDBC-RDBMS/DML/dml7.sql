update my_employee set salary = salary + (salary * .10)
where department_id = 90;

