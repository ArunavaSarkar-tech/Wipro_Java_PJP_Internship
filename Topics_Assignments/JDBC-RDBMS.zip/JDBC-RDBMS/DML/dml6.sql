insert all
into my_employee (205, 'Shelley', 'Higgins', 110, 12000)
into my_employee (100, 'Steven', 'King', 90, 24000)
into my_employee (101, 'Neena', 'Kochhar', 90, 17000)
into my_employee (102, 'Lex De', 'Haan', 90, 17000)
into my_employee (111, 'Ismael', 'Sciarra', 100, 7700)
into my_employee (112, 'Jose Manuel', 'Urman', 100, 7800)
into my_employee (204, 'Hermann', 'Baer', 70, 10000)
select 1 from dual;
