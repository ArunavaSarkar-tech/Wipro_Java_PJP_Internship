insert into my_employee values(202, 'Pat', 'Fay', 20, null);
select * from my_employee;
