create table my_employee as
select employee_id, first_name, last_name, department_id, salary from employees where 1=2;
