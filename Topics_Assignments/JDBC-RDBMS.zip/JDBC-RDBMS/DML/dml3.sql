insert into my_employee values(201, 'Michael', 'Hartstein', 20, 13000);
select * from my_employee;
