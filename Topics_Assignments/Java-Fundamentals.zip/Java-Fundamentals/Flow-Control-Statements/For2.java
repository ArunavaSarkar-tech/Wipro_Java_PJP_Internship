public class For2{
    public static void main(String[] atgs){
        for (int i = 23; i <= 57; i++){
            if (i%2 == 0){
                System.out.println(i);
            }
        }
    }
}
