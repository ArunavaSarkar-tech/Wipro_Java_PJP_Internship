public class Person{
    String name;

    Person(String name){
        this.name = name;
    }

    void setName(String name){
        this.name = name;
    }

    String getName(){
        return this.name;
    }
}
